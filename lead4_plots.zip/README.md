# Lead 4 & Lead 4b Plots — All Datasets

## Overview
These plots measure how walk-Transformer and GNN baselines (walk=blue, GNN=orange) perform on edges with different **structural properties** that make sign prediction hard or easy. All 6 datasets, all 4 models evaluated on the identical shared edge set.

---

## Lead 4: Node Sign-Entropy Heterogeneity (`lead4_entropy_heterogeneity/combined/`)

**What it measures:** For each edge `(u,v)`, compute the Shannon entropy of the sign distribution across each node's neighbors. Then bin edges by these entropies and plot how each model's AUC varies from low-entropy (homogeneous, consistent neighbors) to high-entropy neighborhoods (chaotic, mixed-sign neighbors).

**Four neighborhood variants** (2D binning by source × target entropy):

| File | Source entropy | Target entropy |
|---|---|---|
| `in_in_fixed_b4.png` | H(u's in-sign) | H(v's in-sign) |
| `out_in_fixed_b4.png` | H(u's out-sign) | H(v's in-sign) |
| `inout_inout_fixed_b4.png` | H(all u's incident) | H(all v's incident) |
| `out_out_fixed_b4.png` | H(u's out-sign) | H(v's out-sign) |

**How to read 2D heatmaps:**
- Each colored cell = one entropy bin pair; darker color = higher AUC
- X-axis: target entropy (increasing left→right); Y-axis: source entropy (increasing bottom→top)
- Cells with low sample count or homogeneous labels are grayed out
- Key insight: watch if models degrade *more sharply* as entropy rises (sign of robustness problem)

---

## Lead 4b: 2-Hop Sign-Path-Consistency Entropy (`lead4_twohop_path_consistency/combined/`)

**What it measures:** For each edge `(u,v)`, measure how **consistent** 2-hop paths are. A path is consistent if both its edges have matching signs. Convert the consistency fraction to Shannon entropy: `H=0` means highly predictable (locally balanced), `H=1` means chaotic. Then bin edges by this entropy and plot AUC.

**Three path-direction variants** (1D bar charts):

| File | Paths | Consistency check |
|---|---|---|
| `in_fixed_b4.png` | Backward: `s→t→u` into source | sign(s→t) == sign(t→u)? |
| `out_fixed_b4.png` | Forward: `v→m→k` from target | sign(v→m) == sign(m→k)? |
| `inout_fixed_b4.png` | Pool out + in tallies into one entropy per edge | both directions |

**How to read bar charts:**
- X-axis: entropy bins (increasing heterogeneity/chaos left→right)
- Y-axis: AUC (bars grow from 0.5 baseline = random guessing)
- Height = AUC − 0.5 (so taller = better)
- Numbers under x-ticks: `n` = shared edge count in that bin (identical across all 4 models)
- Blue bars = walk models; orange bars = best GNN baseline

---

## Key Points
1. **Canonical-native:** All models scored on identical shared edge set (walk-covered test edges), so cell/bin sample counts `n` are the *same* for all 4 models — direct apples-to-apples comparison.
2. **No retraining:** These are diagnostic plots of already-trained models' predictions grouped by graph structure, not training-time ablations.
3. **Binary entropy formulation:** `H(p) = -p*log2(p) - (1-p)*log2(1-p)` where `p` is the positive-sign fraction. `H∈[0,1]` bits.

For full methodology & raw numbers per dataset, see:
- `outputs/lead4_entropy_heterogeneity/report.md`
- `outputs/lead4_twohop_path_consistency/report.md`
